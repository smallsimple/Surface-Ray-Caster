#ifndef _NSSHADE
#define _NSSHADE

unsigned char shadeDepth(double);

#endif
