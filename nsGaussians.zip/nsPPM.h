#ifndef _NSPPM
#define _NSPPM

#include <stdio.h>

FILE *openPPMFile(const char *, const int, const int);

#endif
